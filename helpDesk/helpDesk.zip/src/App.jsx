import React from "react";
import "rsuite/dist/rsuite.min.css";
import Dashboard2 from "./pages/Dashboard2";
import Login from "./pages/Login";
import { QueryClient, QueryClientProvider } from "react-query";

const App = () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        refetchOnWindowFocus: false,
      },
    },
  });

  return (
    <div style={{ flex: 1 }}>
      <QueryClientProvider client={queryClient}>
        <Dashboard2 />
        {/* <Login /> */}
      </QueryClientProvider>
    </div>
  );
};

export default App;
export const baseURL = "http://192.168.137.86/HelpDesk/";

import React from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const HeadComponent = ({ id, code, description }) => (
  <div>
    <h2>{id}</h2>
    <p>{code}</p>
    <p>{description}</p>
  </div>
);
function NavList() {
  const [components, setComponents] = React.useState([]);
  const navigate = useNavigate();
  axios
    .get("http://192.168.45.174/Access/GetAccessHeadComponent")
    .then((res) => {
      setComponents(res.data);
    })
    .catch((err) => {
      console.log(err);
    });
  return (
    <div>
      {components.map((component) => (
        <HeadComponent
          key={component.id}
          id={component.id}
          code={component.code}
          description={component.description}
        />
      ))}
    </div>
  );
}

export default NavList;

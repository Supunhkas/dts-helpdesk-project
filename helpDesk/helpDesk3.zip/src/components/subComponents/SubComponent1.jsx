import React from "react";

function SubComponent1() {
  return <div>SubComponent1</div>;
}

export default SubComponent1;

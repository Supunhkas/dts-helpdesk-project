import React from "react";

function SubComponent3() {
  return <div>SubComponent3</div>;
}

export default SubComponent3;

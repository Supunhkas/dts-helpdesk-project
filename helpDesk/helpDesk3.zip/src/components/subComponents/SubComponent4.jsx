import React from "react";

function SubComponent4() {
  return <div>SubComponent4</div>;
}

export default SubComponent4;

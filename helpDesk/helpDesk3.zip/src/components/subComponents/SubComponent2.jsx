import React from "react";

function SubComponent12() {
  return <div>SubComponent12</div>;
}

export default SubComponent12;
